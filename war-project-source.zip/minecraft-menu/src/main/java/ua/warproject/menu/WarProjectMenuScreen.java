package ua.warproject.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

public final class WarProjectMenuScreen extends Screen {
    private static final int LIME = 0xFFC4F047;
    private static final int WHITE = 0xFFF0F4EF;
    private static final int MUTED = 0xFF9EABA5;

    public WarProjectMenuScreen() {
        super(Component.literal("WAR PROJECT"));
    }

    @Override
    protected void init() {
        clearWidgets();
        int buttonWidth = 224;
        int buttonHeight = 34;
        int x = this.width / 2 - buttonWidth / 2;
        int startY = this.height / 2 + 32;
        addRenderableWidget(new TransparentButton(x, startY, buttonWidth, buttonHeight, Component.literal("ГРАТИ ОНЛАЙН"), button -> Minecraft.getInstance().setScreen(new JoinMultiplayerScreen(this))));
        addRenderableWidget(new TransparentButton(x, startY + 42, buttonWidth, buttonHeight, Component.literal("ОДИНОЧНА ГРА"), button -> Minecraft.getInstance().setScreen(new SelectWorldScreen(this))));
        addRenderableWidget(new TransparentButton(x, startY + 84, buttonWidth, buttonHeight, Component.literal("НАЛАШТУВАННЯ"), button -> Minecraft.getInstance().setScreen(new OptionsScreen(this, Minecraft.getInstance().options))));
        TransparentButton exit = new TransparentButton(x, startY + 126, buttonWidth, buttonHeight, Component.literal("ВИЙТИ З ГРИ"), button -> Minecraft.getInstance().stop());
        exit.setTooltip(Tooltip.create(Component.literal("Закрити Minecraft")));
        addRenderableWidget(exit);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int pulse = Mth.floor((Mth.sin((System.currentTimeMillis() % 3000L) / 3000.0F * Mth.TWO_PI) + 1.0F) * 15.0F);
        graphics.fillGradient(0, 0, width, height, 0xFF071012, 0xFF111D1C);
        graphics.fillGradient(0, height / 2, width, height, 0xCC071012, 0xF0070C0E);
        graphics.fill(0, 0, 4, height, LIME);
        graphics.fill(width - 4, 0, width, height, 0xFF273832);
        graphics.drawString(font, Component.literal("WAR PROJECT // FORGE 1.20.1"), 28, 25, MUTED, false);
        graphics.drawString(font, Component.literal("●  SYSTEM ONLINE"), width - 139, 25, LIME, false);
        graphics.drawCenteredString(font, Component.literal("WAR PROJECT"), width / 2, height / 2 - 104, LIME);
        graphics.drawCenteredString(font, Component.literal("ТВІЙ СЕРВЕР · ТВОЇ ПРАВИЛА"), width / 2, height / 2 - 78, WHITE);
        String nickname = Minecraft.getInstance().getUser().getName();
        graphics.fill(width / 2 - 113, height / 2 - 44, width / 2 + 113, height / 2 - 22, 0x66131E1E + pulse);
        graphics.drawCenteredString(font, Component.literal("ELY.BY  //  " + nickname), width / 2, height / 2 - 39, WHITE);
        graphics.drawString(font, Component.literal("01 / ШТАБ"), 28, height - 36, MUTED, false);
        graphics.drawString(font, Component.literal("WAR PROJECT CLIENT"), width - 142, height - 36, MUTED, false);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static final class TransparentButton extends Button {
        private TransparentButton(int x, int y, int width, int height, Component message, OnPress onPress) {
            super(x, y, width, height, message, onPress, DEFAULT_NARRATION);
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            boolean active = isHoveredOrFocused();
            int background = active ? 0xCC21352A : 0x99121C1E;
            graphics.fill(getX(), getY(), getX() + width, getY() + height, background);
            graphics.fill(getX(), getY(), getX() + width, getY() + 1, active ? LIME : 0xFF5E716A);
            graphics.fill(getX(), getY() + height - 1, getX() + width, getY() + height, active ? LIME : 0xFF5E716A);
            graphics.drawCenteredString(Minecraft.getInstance().font, getMessage(), getX() + width / 2, getY() + 12, active ? LIME : WHITE);
        }
    }
}
