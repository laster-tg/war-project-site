const { app, BrowserWindow, ipcMain, shell, safeStorage, clipboard } = require('electron');
const path = require('node:path');
const { constants: fsConstants } = require('node:fs');
const fs = require('node:fs/promises');
const os = require('node:os');
const dns = require('node:dns/promises');
const AdmZip = require('adm-zip');
const { Client } = require('minecraft-launcher-core');

const launcher = new Client();
let gameProcess = null;
let authCache = null;

function createWindow() {
  const win = new BrowserWindow({
    width: 1240, height: 780, minWidth: 960, minHeight: 640,
    frame: false, titleBarStyle: 'hidden', backgroundColor: '#0b1115', icon: path.join(__dirname, 'assets', 'war-project-logo.png'),
    show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  launcher.on('data', (line) => win.webContents.send('game:log', String(line)));
  launcher.on('debug', (line) => win.webContents.send('game:debug', String(line)));
  launcher.on('progress', (state) => win.webContents.send('game:progress', state));
  launcher.on('close', (code) => { gameProcess = null; win.webContents.send('game:close', code); });
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.on('window:minimize', (event) => BrowserWindow.fromWebContents(event.sender)?.minimize());
ipcMain.on('window:maximize', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win?.isMaximized()) win.unmaximize(); else win?.maximize();
});
ipcMain.on('window:close', (event) => BrowserWindow.fromWebContents(event.sender)?.close());
ipcMain.handle('copy-text', async (_event, value) => {
  if (typeof value !== 'string' || value.length > 2000) throw new Error('Текст запиту занадто довгий.');
  clipboard.writeText(value);
  return true;
});
function getGameRoot() { return path.join(app.getPath('appData'), 'WarProjectLauncher'); }
const optimizerMods = [
  { name: 'embeddium-0.3.14+mc1.20.1.jar', url: 'https://cdn.modrinth.com/data/sk9rgfiA/versions/Yf0WdDp1/embeddium-0.3.14%2Bmc1.20.1.jar' },
  { name: 'modernfix-forge-5.25.2+mc1.20.1.jar', url: 'https://cdn.modrinth.com/data/nmDcB62a/versions/scXW7F8Q/modernfix-forge-5.25.2%2Bmc1.20.1.jar' },
  { name: 'ferritecore-6.0.0-forge.jar', url: 'https://cdn.modrinth.com/data/uXXizFIs/versions/ULSumfl4/ferritecore-6.0.0-forge.jar' },
  { name: 'entityculling-forge-1.11.0-mc1.20.1.jar', url: 'https://cdn.modrinth.com/data/NNAgCjsB/versions/cGyEsTtv/entityculling-forge-1.11.0-mc1.20.1.jar' }
];
async function validJar(file) {
  try { return Boolean(new AdmZip(file).getEntry('META-INF/MANIFEST.MF')); } catch { return false; }
}
async function ensureOptimizerMods(target) {
  const installed = []; const warnings = [];
  for (const mod of optimizerMods) {
    const destination = path.join(target, mod.name);
    if (await validJar(destination)) { installed.push(mod.name); continue; }
    try {
      const response = await fetch(mod.url, { headers: { 'User-Agent': 'WarProjectLauncher/1.0' } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const content = Buffer.from(await response.arrayBuffer());
      if (content.length < 30 * 1024) throw new Error('файл надто малий');
      const temporary = `${destination}.download`;
      await fs.writeFile(temporary, content);
      if (!await validJar(temporary)) throw new Error('файл не є JAR');
      await fs.rename(temporary, destination); installed.push(mod.name);
    } catch (error) {
      try { await fs.unlink(`${destination}.download`); } catch {}
      warnings.push(`${mod.name}: ${error.message}`);
    }
  }
  for (const oldName of await fs.readdir(target)) {
    if (/^optifine[_-].*\.jar$/i.test(oldName)) {
      try { await fs.rename(path.join(target, oldName), path.join(target, `${oldName}.disabled`)); } catch (error) { if (error.code !== 'ENOENT') warnings.push(`OptiFine: ${error.message}`); }
    }
  }
  return { installed, warnings };
}
async function ensureBundledClientMods(target) {
  const bundled = ['warprojectmenu-1.0.1.jar'];
  const source = path.join(process.resourcesPath, 'seed-mods');
  for (const name of await fs.readdir(target)) {
    if (/^warprojectmenu-.*\.jar$/i.test(name) && !bundled.includes(name)) await fs.unlink(path.join(target, name));
  }
  for (const name of bundled) {
    const destination = path.join(target, name);
    try { await fs.copyFile(path.join(source, name), destination, fsConstants.COPYFILE_EXCL); }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
  }
}
ipcMain.handle('check-mods', async () => {
  const root = getGameRoot(); const target = path.join(root, 'mods');
  await fs.mkdir(target, { recursive: true });
  const seed = path.join(process.resourcesPath, 'seed-mods');
  const seedMarker = path.join(root, '.initial-mods-installed');
  try {
    await fs.access(seedMarker);
  } catch {
    try {
      for (const name of await fs.readdir(seed)) {
        if (name.toLowerCase().endsWith('.jar')) {
          try { await fs.copyFile(path.join(seed, name), path.join(target, name), fsConstants.COPYFILE_EXCL); } catch (error) { if (error.code !== 'EEXIST') throw error; }
        }
      }
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    await fs.writeFile(seedMarker, new Date().toISOString());
  }
  await ensureBundledClientMods(target);
  const optimization = await ensureOptimizerMods(target);
  const names = (await fs.readdir(target)).filter(name => name.toLowerCase().endsWith('.jar'));
  return { count: names.length, path: target, root, optimization };
});
ipcMain.handle('open-mods-folder', async () => {
  const target = path.join(getGameRoot(), 'mods');
  await fs.mkdir(target, { recursive: true });
  return shell.openPath(target);
});
ipcMain.handle('login-elyby', async (_event, credentials) => {
  if (!credentials || typeof credentials.username !== 'string' || typeof credentials.password !== 'string') throw new Error('Введіть логін і пароль Ely.by.');
  const response = await fetch('https://authserver.ely.by/auth/authenticate', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: credentials.username, password: credentials.password, clientToken: app.getName() + '-' + app.getVersion(), requestUser: true })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.errorMessage || result.error || 'Ely.by не прийняв дані для входу.');
  const profile = result.selectedProfile || result.user?.properties?.profiles?.[0];
  if (!profile?.id || !profile?.name || !result.accessToken) throw new Error('Ely.by не повернув ігровий профіль.');
  authCache = { access_token: result.accessToken, client_token: result.clientToken || app.getName(), uuid: profile.id, name: profile.name, user_properties: '{}', meta: { type: 'mojang', demo: false } };
  if (safeStorage.isEncryptionAvailable()) {
    const tokenPath = path.join(app.getPath('userData'), 'elyby-token.bin');
    await fs.writeFile(tokenPath, safeStorage.encryptString(JSON.stringify(authCache)));
  }
  return { name: profile.name, uuid: profile.id };
});
ipcMain.handle('get-elyby-profile', async () => {
  try {
    if (!authCache && safeStorage.isEncryptionAvailable()) {
      authCache = JSON.parse(safeStorage.decryptString(await fs.readFile(path.join(app.getPath('userData'), 'elyby-token.bin'))));
    }
    return authCache ? { name: authCache.name, uuid: authCache.uuid } : null;
  } catch { return null; }
});
ipcMain.handle('logout-elyby', async () => {
  authCache = null;
  try { await fs.unlink(path.join(app.getPath('userData'), 'elyby-token.bin')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return true;
});
async function ensureForgeInstaller(version) {
  const root = getGameRoot();
  await fs.mkdir(root, { recursive: true });
  const installer = path.join(root, `forge-1.20.1-${version}-installer.jar`);
  try { if ((await fs.stat(installer)).size > 1024 * 1024) return installer; } catch {}
  const url = `https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-${version}/forge-1.20.1-${version}-installer.jar`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Forge ${version} не завантажився (${response.status}).`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length < 1024 * 1024) throw new Error('Завантажений інсталятор Forge пошкоджений.');
  await fs.writeFile(installer, bytes); return installer;
}
async function ensureJava17() {
  const runtimeDir = path.join(app.getPath('userData'), 'runtime');
  try {
    const entries = await fs.readdir(runtimeDir, { recursive: true });
    const java = entries.find((entry) => String(entry).replace(/\\/g, '/').toLowerCase().endsWith('bin/java.exe'));
    if (java) return path.join(runtimeDir, java);
  } catch {}
  await fs.mkdir(runtimeDir, { recursive: true });
  const response = await fetch('https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk');
  if (!response.ok) throw new Error('Не вдалося завантажити Java 17. Перевірте підключення до інтернету.');
  const archive = Buffer.from(await response.arrayBuffer());
  if (archive.length < 10 * 1024 * 1024 || archive.length > 300 * 1024 * 1024) throw new Error('Архів Java має неочікуваний розмір.');
  const zip = new AdmZip(archive);
  for (const entry of zip.getEntries()) {
    if (entry.isDirectory) continue;
    const normalized = entry.entryName.replace(/\\/g, '/');
    if (normalized.startsWith('/') || normalized.split('/').includes('..')) throw new Error('Архів Java містить неприпустимий шлях.');
    const destination = path.join(runtimeDir, ...normalized.split('/'));
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(destination, entry.getData());
  }
  const entries = await fs.readdir(runtimeDir, { recursive: true });
  const java = entries.find((entry) => String(entry).replace(/\\/g, '/').toLowerCase().endsWith('bin/java.exe'));
  if (!java) throw new Error('В архіві Java не знайдено виконуваний файл.');
  return path.join(runtimeDir, java);
}
async function ensureAuthlib() {
  const root = getGameRoot();
  await fs.mkdir(root, { recursive: true });
  const target = path.join(root, 'authlib-injector.jar');
  try {
    const existing = new AdmZip(target);
    if (existing.getEntry('META-INF/MANIFEST.MF')) return target;
  } catch {}
  const response = await fetch('https://github.com/yushijinhun/authlib-injector/releases/download/v1.2.6/authlib-injector-1.2.6.jar');
  if (!response.ok) throw new Error(`Не вдалося завантажити Ely.by authlib-injector (${response.status}).`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length < 50 * 1024) throw new Error('Ely.by authlib-injector завантажився не повністю.');
  const archive = new AdmZip(bytes);
  if (!archive.getEntry('META-INF/MANIFEST.MF')) throw new Error('Завантажений Ely.by authlib-injector не є JAR-файлом.');
  const temporary = `${target}.download`;
  await fs.writeFile(temporary, bytes);
  await fs.rename(temporary, target);
  return target;
}
async function verifyElybyConnection() {
  try {
    await dns.lookup('account.ely.by', { family: 4 });
    const signal = AbortSignal.timeout(8000);
    const response = await fetch('https://account.ely.by/api/authlib-injector', { signal, redirect: 'follow' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
  } catch (error) {
    throw new Error(`Немає з’єднання з Ely.by (${error.message}). Перевірте інтернет і DNS, потім повторіть запуск.`);
  }
}
ipcMain.handle('launch-game', async (event, options) => {
  if (!authCache) {
    const tokenPath = path.join(app.getPath('userData'), 'elyby-token.bin');
    try { authCache = JSON.parse(safeStorage.decryptString(await fs.readFile(tokenPath))); }
    catch { throw new Error('Спочатку увійдіть в Ely.by.'); }
  }
  if (gameProcess) throw new Error('Гру вже запущено.');
  const root = getGameRoot();
  const testMode = options?.testMode === true;
  const server = typeof options?.server === 'string' ? options.server.trim() : '';
  const forge = typeof options?.forge === 'string' && /^47\.\d+\.\d+$/.test(options.forge) ? options.forge : '47.4.23';
  const javaPath = await ensureJava17();
  const forgeInstaller = await ensureForgeInstaller(forge);
  const authAgent = testMode ? null : await ensureAuthlib();
  if (!testMode) await verifyElybyConnection();
  const presetArgs = options?.preset === 'performance'
    ? ['-XX:+UnlockExperimentalVMOptions', '-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:+DisableExplicitGC', '-XX:+UseStringDeduplication', '-XX:+PerfDisableSharedMem', '-XX:G1NewSizePercent=20', '-XX:G1ReservePercent=20', '-XX:MaxGCPauseMillis=75', '-XX:G1HeapRegionSize=8M']
    : ['-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:+UseStringDeduplication', '-XX:MaxGCPauseMillis=125'];
  const customArgs = Array.isArray(options?.args) ? options.args.filter(arg => typeof arg === 'string' && /^-(?!Xm[xs]|javaagent|Djava\.library\.path)[A-Za-z0-9._:+/%=-]+$/.test(arg)).slice(0, 24) : [];
  const maxRam = Math.max(2, Math.min(16, Math.floor(os.totalmem() / 1024 ** 3 * 0.7)));
  const selectedRam = Number(options?.ram) || 6;
  if (selectedRam > maxRam) event.sender.send('game:log', `Вибрано ${selectedRam} ГБ, безпечно доступно до ${maxRam} ГБ; значення обмежено.`);
  const config = {
    authorization: authCache,
    root,
    version: { number: '1.20.1', type: 'release', custom: `1.20.1-forge-${forge}` },
    forge: forgeInstaller,
    javaPath,
    memory: { max: `${Math.max(2, Math.min(selectedRam, maxRam))}G`, min: '2G' },
    customArgs: [...presetArgs, '-Dnetworkaddress.cache.negative.ttl=0', ...(authAgent ? [`-javaagent:${authAgent}=ely.by`] : []), ...customArgs],
    quickPlay: server ? { type: 'multiplayer', identifier: server } : undefined
  };
  event.sender.send('game:log', `Запуск Minecraft 1.20.1 · Forge ${forge}`);
  gameProcess = await launcher.launch(config);
  if (!gameProcess) throw new Error('Ядро запуску не змогло запустити гру. Відкрийте журнал для подробиць.');
  return { started: true };
});
ipcMain.handle('download-authlib', async () => {
  return ensureAuthlib();
});
ipcMain.handle('open-external', async (_event, url) => {
  if (typeof url === 'string' && /^https:\/\//i.test(url)) await shell.openExternal(url);
});
