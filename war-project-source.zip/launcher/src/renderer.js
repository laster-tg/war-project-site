const defaults = { nickname: '', auth: 'elyby', ram: 6, folder: '', server: '', port: '', forge: '47.4.23', java: 'Автоматично · Java 17', preset: 'performance', args: '', mode: 'hoika' };
let settings = { ...defaults, ...JSON.parse(localStorage.getItem('wp-settings') || '{}') };
let logs = JSON.parse(localStorage.getItem('wp-logs') || '[]');
let toastTimer;
const $ = (id) => document.getElementById(id);
function initHeroWarVideo() {
  const canvas = $('heroWarVideo');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let width = 0; let height = 0; let ratio = 1;
  const resize = () => {
    const box = canvas.getBoundingClientRect(); ratio = Math.min(window.devicePixelRatio || 1, 2);
    width = Math.max(1, Math.round(box.width)); height = Math.max(1, Math.round(box.height));
    canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio); ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  };
  const mountain = (x, y, size, color) => { ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x - size, height); ctx.lineTo(x, y); ctx.lineTo(x + size, height); ctx.closePath(); ctx.fill(); };
  const smoke = (x, y, radius, alpha) => {
    const gradient = ctx.createRadialGradient(x, y, 2, x, y, radius);
    gradient.addColorStop(0, `rgba(154, 173, 148, ${alpha})`); gradient.addColorStop(.38, `rgba(79, 94, 80, ${alpha * .65})`); gradient.addColorStop(1, 'rgba(19, 29, 30, 0)');
    ctx.fillStyle = gradient; ctx.beginPath(); ctx.ellipse(x, y, radius * 1.4, radius, 0, 0, Math.PI * 2); ctx.fill();
  };
  const draw = (now) => {
    const time = now / 1000; const drift = Math.sin(time * .24) * 22;
    ctx.clearRect(0, 0, width, height);
    const sky = ctx.createLinearGradient(0, 0, 0, height); sky.addColorStop(0, '#172b2d'); sky.addColorStop(.58, '#1a302d'); sky.addColorStop(1, '#091012'); ctx.fillStyle = sky; ctx.fillRect(0, 0, width, height);
    mountain(width * .16 + drift, height * .35, width * .32, '#15262a'); mountain(width * .53 + drift * .7, height * .22, width * .36, '#112226'); mountain(width * .87 + drift, height * .39, width * .3, '#132427');
    ctx.fillStyle = '#101a1c'; ctx.fillRect(0, height * .61, width, height * .39);
    smoke(width * .70 + Math.sin(time * .37) * 48, height * .42, 110 + Math.sin(time) * 14, .42);
    smoke(width * .24 + Math.cos(time * .28) * 37, height * .58, 95, .3);
    smoke(width * .88 + Math.sin(time * .21) * 25, height * .69, 125, .25);
    ctx.save(); ctx.translate(width * .68 + drift * .18, height * .64); ctx.fillStyle = '#0a1112'; ctx.fillRect(-70, -15, 138, 18); ctx.fillRect(-30, -35, 55, 23); ctx.fillRect(15, -42, 84, 6); ctx.beginPath(); ctx.ellipse(-43, 8, 24, 8, 0, 0, Math.PI * 2); ctx.ellipse(42, 8, 24, 8, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    const flash = Math.max(0, Math.sin(time * 1.75 + 1.2));
    if (flash > .72) { const x = width * .78; const y = height * .42; const fire = ctx.createRadialGradient(x, y, 0, x, y, 54); fire.addColorStop(0, `rgba(255,223,126,${flash})`); fire.addColorStop(.2, `rgba(239,111,57,${flash * .75})`); fire.addColorStop(1, 'rgba(239,111,57,0)'); ctx.fillStyle = fire; ctx.beginPath(); ctx.arc(x, y, 54, 0, Math.PI * 2); ctx.fill(); }
    const tracer = (time * 280) % (width + 190) - 95; ctx.strokeStyle = 'rgba(213,244,101,.72)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(tracer - 120, height * .29); ctx.lineTo(tracer, height * .43); ctx.stroke();
    ctx.fillStyle = 'rgba(198,240,71,.14)'; for (let i = 0; i < 50; i += 1) { const x = (i * 139 + Math.floor(time * 12)) % width; const y = (i * 47) % height; ctx.fillRect(x, y, 1, 1); }
    requestAnimationFrame(draw);
  };
  resize(); window.addEventListener('resize', resize); requestAnimationFrame(draw);
}
initHeroWarVideo();
let bootProgress = 0;
function updateBoot(progress, status) {
  bootProgress = Math.max(bootProgress, Math.min(100, progress));
  $('bootLine').style.width = `${bootProgress}%`;
  $('bootStatus').textContent = status;
  $('bootPercent').textContent = `${String(Math.round(bootProgress)).padStart(2, '0')}%`;
  $('bootStep').textContent = `${String(Math.min(4, Math.max(1, Math.ceil(bootProgress / 25)))).padStart(2, '0')} / 04`;
}
function finishBoot() { updateBoot(100, 'СИСТЕМА ГОТОВА ДО ОПЕРАЦІЇ'); setTimeout(() => $('bootScreen').classList.add('done'), 620); }
function log(message, kind = 'info') {
  const now = new Date().toLocaleTimeString('uk-UA', { hour12: false });
  logs.unshift({ now, message, kind }); logs = logs.slice(0, 80);
  localStorage.setItem('wp-logs', JSON.stringify(logs)); renderLogs();
}
function renderLogs() {
  const list = $('logList'); if (!list) return;
  list.innerHTML = logs.length ? logs.map(x => `<div class="log-entry"><time>${escapeHtml(x.now)}</time><i class="log-${escapeHtml(x.kind)}"></i><span>${escapeHtml(x.message)}</span></div>`).join('') : '<div class="empty-log">Подій поки немає</div>';
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])); }
function toast(message) { const el = $('toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2800); }
function openOverlay(id) { const el = $(id); el.classList.add('open'); el.setAttribute('aria-hidden', 'false'); }
function closeOverlay(id) { const el = $(id); el.classList.remove('open'); el.setAttribute('aria-hidden', 'true'); }
function renderRam() {
  const list = $('ramSelect');
  list.innerHTML = Array.from({ length: 15 }, (_, i) => i + 2).map(n => `<button role="option" aria-selected="${n === Number(settings.ram)}" class="ram-option ${n === Number(settings.ram) ? 'selected' : ''}" data-ram="${n}">${n}<small>ГБ</small></button>`).join('');
  list.querySelectorAll('[data-ram]').forEach(btn => btn.addEventListener('click', () => { settings.ram = Number(btn.dataset.ram); $('ramValue').textContent = `${settings.ram} ГБ`; renderRam(); }));
  $('ramValue').textContent = `${settings.ram} ГБ`;
}
function fillSettings() {
  $('serverInput').value = settings.server; $('portInput').value = settings.port; $('forgeVersion').value = settings.forge;
  $('javaVersion').value = ['Автоматично · Java 17', 'Java 17'].includes(settings.java) ? settings.java : defaults.java;
  $('jvmPreset').value = settings.preset; $('jvmArgs').value = settings.args; $('jvmArgs').hidden = settings.preset !== 'custom'; renderRam();
}
let loggedInName = '';
function setText(id, value) { const element = $(id); if (element) element.textContent = value; }
function updateModpack(result) {
  const count = Number(result?.count) || 0;
  setText('modsValue', String(count)); setText('modsCount', count ? `${count} МОДІВ` : 'ПАПКА ПОРОЖНЯ');
  setText('modsPath', result?.path || '%APPDATA%\\WarProjectLauncher\\mods');
  const optimization = result?.optimization;
  if (optimization?.installed?.length) log(`Оптимізацію встановлено: ${optimization.installed.length} моди.`);
  if (optimization?.warnings?.length) log(`Не всі моди оптимізації встановлено: ${optimization.warnings.join('; ')}`, 'warn');
}
function renderProfile() {
  const nickname = settings.nickname || 'УВІЙТИ';
  setText('topAccountName', nickname); setText('topAccountStatus', loggedInName ? 'ELY.BY · ПІДКЛЮЧЕНО' : 'НАТИСНІТЬ ДЛЯ ВХОДУ');
  setText('topAvatar', loggedInName ? nickname.slice(0, 2).toUpperCase() : 'WP');
  setText('launchHint', loggedInName ? 'Збірка готова до запуску' : 'Увійдіть через Ely.by');
  renderAccount();
}
function renderAccount() {
  const signedIn = Boolean(loggedInName);
  const signedOut = $('accountLoggedOut'); const signedInPanel = $('accountLoggedIn');
  if (!signedOut || !signedInPanel) return;
  signedOut.hidden = signedIn; signedInPanel.hidden = !signedIn;
  if (signedIn) { setText('accountName', loggedInName); setText('accountAvatar', loggedInName.slice(0, 2).toUpperCase()); }
}
function renderMode() {
  const selected = settings.mode === 'dm' ? 'dm' : 'hoika';
  document.querySelectorAll('[data-mode]').forEach(button => { const active = button.dataset.mode === selected; button.classList.toggle('selected', active); button.setAttribute('aria-checked', String(active)); });
  $('modeCaption').textContent = `Вибрано режим «${selected === 'dm' ? 'ДМ' : 'Хойка'}»`;
}
document.querySelectorAll('[data-mode]').forEach(button => button.addEventListener('click', () => { settings.mode = button.dataset.mode; localStorage.setItem('wp-settings', JSON.stringify(settings)); renderMode(); log(`Вибрано режим «${settings.mode === 'dm' ? 'ДМ' : 'Хойка'}»`); }));
document.querySelectorAll('[data-window]').forEach(b => b.addEventListener('click', () => window.launcher?.[b.dataset.window]?.()));
document.querySelector('.titlebar').addEventListener('dblclick', event => { if (!event.target.closest('.window-actions')) window.launcher?.maximize?.(); });
$('openSettings').addEventListener('click', () => { fillSettings(); openOverlay('settingsOverlay'); });
$('openAccount').addEventListener('click', () => { renderAccount(); openOverlay('accountOverlay'); if (!loggedInName) setTimeout(() => $('elybyUsername').focus(), 100); });
$('openModsSettings').addEventListener('click', async () => { await window.launcher.openModsFolder(); });
$('openPrivilege').addEventListener('click', () => openOverlay('privilegeOverlay'));
$('copyPrivilegeRequest').addEventListener('click', async () => {
  const nickname = loggedInName || settings.nickname || 'мій нік';
  const request = `Вітаю! Хочу придбати привілею «Завойовник» за 100 ₴. Мій нік Ely.by: ${nickname}. Надішліть, будь ласка, реквізити для оплати.`;
  try { await window.launcher.copyText(request); log('Запит на реквізити для привілеї скопійовано.'); toast('Запит на реквізити скопійовано.'); }
  catch (error) { log(`Не вдалося скопіювати запит: ${error.message}`, 'warn'); toast(error.message); }
});
$('loginElyby').addEventListener('click', async () => {
  const username = $('elybyUsername').value.trim(); const password = $('elybyPassword').value;
  if (!username || !password) return toast('Введіть логін і пароль Ely.by.');
  $('loginElyby').disabled = true; $('loginElyby').textContent = 'ПІДКЛЮЧЕННЯ…';
  try { const profile = await window.launcher.loginElyby({ username, password }); $('elybyPassword').value = ''; loggedInName = profile.name; settings.nickname = profile.name; localStorage.setItem('wp-settings', JSON.stringify(settings)); log(`Вхід Ely.by виконано: ${profile.name}`); renderProfile(); closeOverlay('accountOverlay'); toast(`Вітаємо, ${profile.name}`); }
  catch (error) { log(`Помилка входу Ely.by: ${error.message}`, 'warn'); toast(error.message); }
  finally { $('loginElyby').disabled = false; $('loginElyby').textContent = 'УВІЙТИ ЧЕРЕЗ ELY.BY'; }
});
$('openLogs').addEventListener('click', () => { renderLogs(); openOverlay('logsOverlay'); });
document.querySelectorAll('[data-close="settings"]').forEach(b => b.addEventListener('click', () => closeOverlay('settingsOverlay')));
document.querySelectorAll('[data-close="logs"]').forEach(b => b.addEventListener('click', () => closeOverlay('logsOverlay')));
document.querySelectorAll('[data-close="privilege"]').forEach(b => b.addEventListener('click', () => closeOverlay('privilegeOverlay')));
$('logoutElyby').addEventListener('click', async () => {
  try { await window.launcher.logoutElyby(); loggedInName = ''; settings.nickname = ''; localStorage.setItem('wp-settings', JSON.stringify(settings)); renderProfile(); toast('Ви вийшли з акаунта Ely.by.'); }
  catch (error) { log(`Помилка виходу: ${error.message}`, 'warn'); toast(error.message); }
});
document.querySelectorAll('[data-close="account"]').forEach(b => b.addEventListener('click', () => closeOverlay('accountOverlay')));
document.querySelectorAll('.overlay').forEach(el => el.addEventListener('click', e => { if (e.target === el) closeOverlay(el.id); }));
$('jvmPreset').addEventListener('change', e => { $('jvmArgs').hidden = e.target.value !== 'custom'; });
$('saveSettings').addEventListener('click', () => {
  settings = { ...settings, nickname: loggedInName || settings.nickname, server: $('serverInput').value.trim(), port: $('portInput').value.trim(), forge: $('forgeVersion').value.trim() || defaults.forge, java: $('javaVersion').value, preset: $('jvmPreset').value, args: $('jvmArgs').value.trim() };
  localStorage.setItem('wp-settings', JSON.stringify(settings)); renderProfile(); closeOverlay('settingsOverlay'); log('Налаштування профілю збережено'); toast('Налаштування збережено');
});
let launchBusy = false;
async function launchGame() {
  if (!loggedInName) { log('Для запуску потрібен вхід Ely.by.', 'warn'); toast('Спочатку увійдіть в Ely.by.'); renderAccount(); openOverlay('accountOverlay'); return; }
  if (launchBusy) return;
  launchBusy = true; setText('launchHint', 'Підготовка гри…'); setText('modsCount', 'ПЕРЕВІРКА МОДІВ…');
  try {
    const packed = await window.launcher.checkMods(); if (!packed.count) throw new Error(`Папка модів порожня: ${packed.path}`);
    updateModpack(packed); setText('launchHint', 'Підготовка Forge…');
    const userArgs = settings.preset === 'custom' ? (settings.args.match(/(?:[^\s"]+|"[^"]*")+/g) || []).map(arg => arg.replace(/^"|"$/g, '')) : [];
    await window.launcher.launchGame({ ram: settings.ram, forge: settings.forge, preset: settings.preset, args: userArgs, server: settings.server ? `${settings.server}${settings.port ? `:${settings.port}` : ''}` : '' });
    setText('launchHint', 'Перевірка запуску гри…'); log('Процес Minecraft запущено; очікуємо ініціалізацію Java.');
  } catch (error) { launchBusy = false; setText('modsCount', 'ПОМИЛКА'); setText('launchHint', 'Не вдалося запустити'); log(`Помилка запуску: ${error.message}`, 'warn'); toast(error.message); }
}
$('launch').addEventListener('click', () => launchGame());
$('clearLogs').addEventListener('click', () => { logs = []; localStorage.setItem('wp-logs', '[]'); renderLogs(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeOverlay('settingsOverlay'); closeOverlay('logsOverlay'); closeOverlay('privilegeOverlay'); closeOverlay('accountOverlay'); } });
window.launcher?.onGameLog?.(line => { const text = String(line).trim(); if (text && text.toLowerCase() !== 'assets') log(text); });
window.launcher?.onGameProgress?.(state => { const title = state?.type || state?.task || 'Завантаження файлів гри'; setText('launchHint', title); log(title); });
window.launcher?.onGameClose?.(code => { launchBusy = false; setText('launchHint', `Гру закрито (${code})`); log(`Гру закрито з кодом ${code}`, code === 0 ? 'info' : 'warn'); });
window.launcher?.getElybyProfile?.().then(profile => { if (profile) { loggedInName = profile.name; settings.nickname = profile.name; renderProfile(); } });
renderProfile(); renderLogs(); renderRam(); renderMode();
updateBoot(12, 'ІНІЦІАЛІЗАЦІЯ ЗАХИЩЕНОГО КАНАЛУ');
setTimeout(() => updateBoot(30, 'ЗАВАНТАЖЕННЯ ІНТЕРФЕЙСУ ШТАБУ'), 170);
updateBoot(40, 'ПЕРЕВІРКА ФАЙЛІВ ЗБІРКИ');
window.launcher?.checkMods?.().then(result => { updateModpack(result); updateBoot(82, result.count ? 'МОДПАК ПЕРЕВІРЕНО' : 'ПАПКУ МОДІВ СТВОРЕНО'); }).catch(error => { log(`Перевірка модів: ${error.message}`, 'warn'); setText('modsCount', 'ПЕРЕВІРКА НЕВДАЛА'); updateBoot(82, 'ПЕРЕВІРКУ ЗАВЕРШЕНО'); });
setTimeout(() => updateBoot(92, 'ПІДГОТОВКА ДО РОЗГОРТАННЯ'), 680);
setTimeout(finishBoot, 1250);
log('War Project Launcher готовий. Minecraft 1.20.1 · Forge ' + settings.forge);
