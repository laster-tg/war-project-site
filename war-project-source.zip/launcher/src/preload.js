const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('launcher', {
  minimize: () => ipcRenderer.send('window:minimize'),
  maximize: () => ipcRenderer.send('window:maximize'),
  close: () => ipcRenderer.send('window:close'),
  checkMods: () => ipcRenderer.invoke('check-mods'),
  openModsFolder: () => ipcRenderer.invoke('open-mods-folder'),
  copyText: (text) => ipcRenderer.invoke('copy-text', text),
  loginElyby: (credentials) => ipcRenderer.invoke('login-elyby', credentials),
  getElybyProfile: () => ipcRenderer.invoke('get-elyby-profile'),
  logoutElyby: () => ipcRenderer.invoke('logout-elyby'),
  downloadAuthlib: () => ipcRenderer.invoke('download-authlib'),
  launchGame: (options) => ipcRenderer.invoke('launch-game', options),
  onGameLog: (callback) => ipcRenderer.on('game:log', (_event, line) => callback(line)),
  onGameProgress: (callback) => ipcRenderer.on('game:progress', (_event, state) => callback(state)),
  onGameClose: (callback) => ipcRenderer.on('game:close', (_event, code) => callback(code)),
  openExternal: (url) => ipcRenderer.invoke('open-external', url)
});
